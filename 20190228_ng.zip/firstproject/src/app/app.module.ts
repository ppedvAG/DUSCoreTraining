import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TimeComponent } from './time/time.component';
import { DiceComponent } from './dice/dice.component';
import { RatingComponent } from './rating/rating.component';
import { RomanNumberComponent } from './roman-number/roman-number.component';
import { CardComponent } from './card/card.component';
import { DiashowComponent } from './diashow/diashow.component';
import { HomeawayComponent } from './homeaway/homeaway.component';
import { ClickCounterComponent } from './click-counter/click-counter.component';
import { TimerComponent } from './timer/timer.component';
import { FormBsp1Component } from './form-bsp1/form-bsp1.component';
import { FormBsp2Component } from './form-bsp2/form-bsp2.component';
import { FormBsp3Component } from './form-bsp3/form-bsp3.component';

@NgModule({
  declarations: [
    AppComponent,
    TimeComponent,
    DiceComponent,
    RatingComponent,
    RomanNumberComponent,
    CardComponent,
    DiashowComponent,
    HomeawayComponent,
    ClickCounterComponent,
    TimerComponent,
    FormBsp1Component,
    FormBsp2Component,
    FormBsp3Component
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
