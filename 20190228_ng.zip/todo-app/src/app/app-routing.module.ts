import { TodosComponent } from './todos/todos.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StartviewComponent } from './startview/startview.component';
import { TodoComponent } from './todo/todo.component';

const routes: Routes = [
  { path: 'todos', component: TodosComponent},
  { path: 'startview', component: StartviewComponent},
  { path: '', redirectTo: '/startview', pathMatch: 'full'},
  { path: 'todo/:id', component: TodoComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
