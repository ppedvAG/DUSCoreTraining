import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dice',
  /* template: `<hr>
  <p>
    dice works!
  </p>
  <p>Gewürfelt! Die Zahl ist: {{zahl}}</p>` */
  templateUrl: './dice.component.html',
  styleUrls: ['./dice.component.css']
})
export class DiceComponent implements OnInit {
  zahl: number;

  constructor() {
    this.zahl = Math.ceil(Math.random()*6);
   }

  ngOnInit() {
  }

}
