import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBsp1Component } from './form-bsp1.component';

describe('FormBsp1Component', () => {
  let component: FormBsp1Component;
  let fixture: ComponentFixture<FormBsp1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormBsp1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormBsp1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
