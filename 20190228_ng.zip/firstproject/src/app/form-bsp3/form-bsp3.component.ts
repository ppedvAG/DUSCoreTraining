import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-bsp3',
  templateUrl: './form-bsp3.component.html',
  styleUrls: ['./form-bsp3.component.css']
})
export class FormBsp3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  logForm(formvalues) {
    console.log(formvalues);

  }

}
