import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {
@Input() time: number;
@Output() tick: EventEmitter<number> = new EventEmitter<number>();
@Output() start: EventEmitter<void> = new EventEmitter<void>();
remainingTime: number;
intervalId: number;
started: boolean = false;

  constructor() { }

  ngOnInit() {
    this.remainingTime = this.time;
  }

  onClick() {
    if (this.started) {
      return;
    }
    this.start.emit();
    this.started = true;
    this.intervalId = window.setInterval(
      () => {
        this.remainingTime--;
        this.tick.emit(this.remainingTime);
        if (this.remainingTime === 0) {
          clearInterval(this.intervalId);
        }
      }, 1000
    );
  }

}
