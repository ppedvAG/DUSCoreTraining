import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {
  @Input() stars: number;
  starString: string;

  constructor() { }

  ngOnInit() {
    this.starString = '*'.repeat(this.stars);
  }

}
