import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Düsseldorf';
  timerMessage = '';
  handleStart() {
    this.timerMessage = 'Timer Started';
  }
  handleTick(event: number) {
    this.timerMessage = `Remaining Time: ${event}`;
    if (event <= 3) {
      this.timerMessage += 'Time is almost up!';
    }
  }



}



