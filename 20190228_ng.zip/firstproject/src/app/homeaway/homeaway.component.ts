import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeaway',
  templateUrl: './homeaway.component.html',
  styleUrls: ['./homeaway.component.css']
})
export class HomeawayComponent implements OnInit {
  message: string;
  isHome: boolean;

  constructor() {
   }
  ngOnInit() {
  }
  getMessage() {
    return this.isHome ? 'Home' : 'Away';
  }
  home() {
    this.isHome = true;
  }
  away() {
    this.isHome = false;
  }
}
