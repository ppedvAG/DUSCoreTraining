import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-bsp1',
  templateUrl: './form-bsp1.component.html',
  styleUrls: ['./form-bsp1.component.css']
})
export class FormBsp1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
