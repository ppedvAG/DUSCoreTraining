import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Todo } from './todo';


@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService extends InMemoryDbService {
  createDb() {
    const todos = [
      { id: 11, title: 'zur Post'},
      { id: 12, title: 'Fahrrad reparieren'},
      { id: 13, title: 'einkaufen'},
      { id: 14, title: 'Friseurtermin'},
      { id: 15, title: 'putzen'},
      { id: 16, title: 'Geschenke kaufen'},
      { id: 17, title: 'Sport'},
      { id: 18, title: 'Miete überweisen'},
      { id: 19, title: 'Bahntickets'},
      { id: 20, title: 'Zahnarzt'}
    ];
    return {todos};
  }

  genId(todos: Todo[] ):number {
    return todos.length > 0 ? Math.max(...todos.map(todo => todo.id)) + 1 : 11;
  }
}
