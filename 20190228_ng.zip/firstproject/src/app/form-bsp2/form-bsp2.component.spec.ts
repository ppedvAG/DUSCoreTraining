import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBsp2Component } from './form-bsp2.component';

describe('FormBsp2Component', () => {
  let component: FormBsp2Component;
  let fixture: ComponentFixture<FormBsp2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormBsp2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormBsp2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
