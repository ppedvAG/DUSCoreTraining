import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MessageService } from './message.service';
import { Observable, of } from 'rxjs';
import {catchError, map, tap } from 'rxjs/operators';
import { Todo } from './todo';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private todosUrl = 'http://192.168.178.82:63382/api/todos';

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }



    getTodos (): Observable<Todo[]> {
      return this.http.get<Todo[]>(this.todosUrl)
      .pipe(
        tap(_ => this.log('fetched todos')),
        catchError(this.handleError('getTodos', []))
      );
    }

    getTodo(id: number): Observable<Todo> {
      const url = `${this.todosUrl}/${id}`;
      return this.http.get<Todo>(url)
      .pipe(
        tap(_ => this.log(`fetched todo id=${id}`)),
        catchError(this.handleError<Todo>(`getTodo id=${id}`))
      );
    }

    addTodo(todo: Todo ): Observable<Todo> {
      return this.http.post<Todo>(this.todosUrl, todo, httpOptions)
      .pipe(
        tap((newTodo: Todo) => this.log(`added todo with id=${newTodo.id}`)),
        catchError(this.handleError<Todo>('addTodo'))
      );
    }

    private handleError<T> (operation = 'operation', result?: T) {
      return (error: any): Observable<T> => {
        console.error(error);
        this.log(`${operation} failed: ${error.message}`);
        return of(result as T);
      };
    }

    private log(message: string) {
      this.messageService.add(`TodoService: ${message}`);
    }
}
