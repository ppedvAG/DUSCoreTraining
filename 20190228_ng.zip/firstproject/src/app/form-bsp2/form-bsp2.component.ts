import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-bsp2',
  templateUrl: './form-bsp2.component.html',
  styleUrls: ['./form-bsp2.component.css']
})
export class FormBsp2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
