import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBsp3Component } from './form-bsp3.component';

describe('FormBsp3Component', () => {
  let component: FormBsp3Component;
  let fixture: ComponentFixture<FormBsp3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormBsp3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormBsp3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
