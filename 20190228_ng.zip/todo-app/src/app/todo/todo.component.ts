import { Component, OnInit, Input } from '@angular/core';
import { Todo } from '../todo';
import { TodoService } from '../todo.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  @Input() todo: Todo;
  constructor(
    private todoService: TodoService,
    private route: ActivatedRoute,
    private location: Location
  ) { }
  ngOnInit() {
    this.getTodo();
  }
  getTodo(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.todoService.getTodo(id)
    .subscribe(todo => this.todo = todo);
  }

  goBack(): void {
    this.location.back();

  }





}
